package pl.gdynia.amw.oop.lab2;

public class Square extends Figure {
    //constructor
    public Square() {

    }

    //atributes
    private int a = 5;

    @Override
    public void printSurfaceArea() {
        System.out.println("Surface area of square: " + a * a);
    }

    public void printCircuit() {
        System.out.println("Circuit of square: " + 4 * a);
    }

}
