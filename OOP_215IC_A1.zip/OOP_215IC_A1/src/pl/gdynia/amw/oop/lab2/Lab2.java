package pl.gdynia.amw.oop.lab2;

public class Lab2 {
    public void run() {
        Figure triangle = new Triangle();
        Figure square = new Square();

        triangle.setName("Triangle!");
        System.out.println(triangle.getName());
        triangle.printCircuit();
        triangle.printSurfaceArea();

        square.setName("\nSquare!");
        System.out.println(triangle.getName());
        square.printCircuit();
        square.printSurfaceArea();
    }
}
