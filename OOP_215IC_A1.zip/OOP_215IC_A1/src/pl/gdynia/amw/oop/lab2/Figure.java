package pl.gdynia.amw.oop.lab2;

public class Figure {
    //atribute
    private String name;

    //constructors
    public Figure() {

    }

    public Figure(String name) {
        this.name = name;
    }

    //getters and setters
    public void setName(String newName) {
        this.name = newName;
    }

    public String getName() {
        return name;
    }

    //methods
    public void printSurfaceArea() {
        System.out.println("TO DO");
    }

    public void printCircuit() {
        System.out.println("TO DO");
    }
}
