package pl.gdynia.amw.oop.lab2;

public class Triangle extends Figure {
    //constructor
    public Triangle() {

    }

    //atributes
    private int a;
    private int b;
    private int c;
    private int h;

    @Override
    public void printSurfaceArea() {
        a = 5;
        h = 3;
        System.out.println("Surface area of triangle: " + a * h / 2);
    }

    public void printCircuit() {
        a = 6;
        b = 5;
        c = b;
        System.out.println("Circuit of triangle: " + (a + b + c));
    }

    public Triangle(String newName) {
        super("This is second solution of give name of figure");
    }
}
