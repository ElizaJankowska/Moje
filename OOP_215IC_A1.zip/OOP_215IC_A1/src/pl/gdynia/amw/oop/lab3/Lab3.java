package pl.gdynia.amw.oop.lab3;

public class Lab3 {
    public void run() {
        Animal cat = new Cat("Cat");
        Animal dog = new Dog("Dog");
        cat.printName();
        cat.voice();

        dog.printName();
        dog.voice();
    }
}
