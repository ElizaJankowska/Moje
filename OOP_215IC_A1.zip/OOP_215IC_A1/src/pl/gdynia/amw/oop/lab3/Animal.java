package pl.gdynia.amw.oop.lab3;

public interface Animal {
    default void printName() {
        System.out.println("Animal");
    }

    void voice();
}
