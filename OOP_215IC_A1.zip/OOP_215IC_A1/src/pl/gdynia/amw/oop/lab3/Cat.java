package pl.gdynia.amw.oop.lab3;

public class Cat implements Animal {
    private String name;

    public Cat(String name) {
        setName(name);
    }

    //getters and setters
    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void printName() {
        System.out.println(getName());
    }

    @Override
    public void voice() {
        System.out.println("miau miau");
    }
}
