package pl.gdynia.amw.oop.lab3;

public class Dog implements Animal {
    private String name;
    public Dog(String name) {
        this.name = name;
    }

    public void printName() {
        System.out.println(name);
    }

    @Override
    public void voice() {
        System.out.println("hau hau");
    }
}
