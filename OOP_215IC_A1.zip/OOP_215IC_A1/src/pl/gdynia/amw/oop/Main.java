package pl.gdynia.amw.oop;

import pl.gdynia.amw.oop.lab3.Lab3;

public class Main {

    public static void main(String args[]) {
        var lab = new Lab3();
        lab.run();
    }
}
