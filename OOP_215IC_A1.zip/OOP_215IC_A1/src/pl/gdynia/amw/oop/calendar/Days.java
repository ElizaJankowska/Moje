package pl.gdynia.amw.oop.calendar;

import java.util.ArrayList;

public class Days {
    ArrayList<Events> events = new ArrayList<>();
}
