package pl.gdynia.amw.oop.calendar;

public abstract class Events {

}
