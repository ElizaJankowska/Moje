package pl.gdynia.amw.oop.calendar;

public class Reminder {
}
