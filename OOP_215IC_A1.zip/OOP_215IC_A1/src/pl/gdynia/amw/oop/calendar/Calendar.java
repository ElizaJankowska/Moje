package pl.gdynia.amw.oop.calendar;

import java.util.ArrayList;
import java.util.Scanner;

public class Calendar {
    Scanner skaner = new Scanner(System.in);
    boolean exe = false;
    //stworenie listy zawierającej dni miesiąca typu "obiekt"
    ArrayList<Days> month = new ArrayList<>();
    //wypełnienie listy
    for(int i = 1; i < 32; i++){
        month.add();
    }
    //menu wyboru użytkownika
    while(!exe){
        System.out.println("Welcome to the calendar!");
        System.out.println("Type 1 to add your event");
        System.out.println("Type 2 to remove your event");
        System.out.println("Type 3 to show your events");
        System.out.println("Type 4 to exit");
        int check = skaner.nextInt();
        switch(check) {
            case 1:
                System.out.println("On which day do you want to schedule the event?");
                System.out.println("What event do you want to add?");
                //typy wydarzeń
                break;
            case 2:
                System.out.println("On which day do you want to remove the event?");
                //jakie dostępne
                //if notNull then:
                System.out.println("What event do you want to remove?");
                //else
                System.out.println("You don't have any event");
                break;
            case 3:
                System.out.println("Choose the day");
                break;
            case 4:
                System.out.println("Bye!");
                exe = true;
                break;
            default:
                System.out.println("You put something wrong!");
        }
    }
}
