package pl.gdynia.amw.oop.lab1;

public class Lab1 {
    public void run() {
        System.out.println("First lab file by Eliza Jankowska");
    }
}
